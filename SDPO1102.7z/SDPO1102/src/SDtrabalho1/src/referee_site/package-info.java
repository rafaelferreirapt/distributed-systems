/**
 * In this package there are the Referee Site and all other interfaces to the entities 
 * acess to the methods, for example, ICoach is the Coach interface of Referee Site instance.
 */
package referee_site;