/**
 * In this package there are the Bench and all other interfaces to the entities 
 * acess to the methods, for example, ICoach is the Coach interface of Bench instance.
 */
package bench;