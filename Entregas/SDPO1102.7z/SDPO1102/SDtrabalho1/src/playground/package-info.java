/**
 * In this package there are the Playground and all other interfaces to the entities 
 * acess to the methods, for example, IContestant is the Contestant interface of Playground instance.
 */
package playground;