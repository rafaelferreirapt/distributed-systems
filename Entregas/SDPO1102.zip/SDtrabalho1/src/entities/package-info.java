/**
 * In this package there are some entities: Coach, Contestant and Referee.
 */
package entities;