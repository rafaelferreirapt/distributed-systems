/**
 * The log will be the gateway to all the information of the match, games, trials,
 * strengths of the players. It will be responsible too for write in one file with
 * the log of the match.
 */
package general_info_repo;